import { React, useEffect } from "react";
import Banner from "../components/Banner";
import Carsole from "../components/Carsole";
import Productgrid from "../components/Productgrid";
import Review from "../components/Review";
import Footer from "../components/Footer";

const Home = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      <Banner />
      <Carsole />
      <Productgrid />
      <Review />
      <Footer />
    </div>
  );
};

export default Home;
