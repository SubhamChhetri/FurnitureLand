import React from "react";
import { Link } from "react-router-dom";
import ReactStars from "react-rating-stars-component";
import "./css/product.css";

const Product = (props) => {
  const options = {
    edit: false,
    color: "rgb(20,20,20,0.1)",
    activeColor: "tomato",
    size: window.innerWidth < 600 ? 20 : 25,

    value: props.data.ratings,
    isHalf: true,
  };

  return (
   
    <div id="arrange">
      <div className="boxe">
        <Link className="productCards" to={`/${props.data._id}/product`}>
          <img src={props.data.img} alt={props.data.name} />
          <p>{props.data.name}</p>
          <p>{}</p>
          <div className="star">
            <ReactStars {...options} />
            <span className="rev">({props.data.numOfReviews}reviews)</span>
          </div>
          <span>{`$${props.data.price}`}</span>
        </Link>

      </div>
    </div>
  );
};

export default Product;
