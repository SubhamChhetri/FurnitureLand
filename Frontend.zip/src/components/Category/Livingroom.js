import React, { useEffect,useState } from "react";
import "./csscat/categorys.css";
import Product from "../Product.js";

import bedroom from "../image/bedroom.svg";
import livingroom from "../image/livingroom.svg";
import dining from "../image/dining.svg";
import kitchen from "../image/kitchen.svg";
import office from "../image/office.svg";
import { BrowserRouter as Router, Outlet, Link } from "react-router-dom";

import { Fragment } from "react";

const Livingroom = () => {
  window.scrollTo(0, 0)
  const [loadedUser, setLoadedUsers] = useState();
  useEffect(() => {
    const sendRequest = async () => {
      try {
        const response = await fetch("http://localhost:5000/furniture");
        const responseData = await response.json();
        setLoadedUsers(responseData.furnitures);
      } catch (err) {
        console.log(err);
      }
    };
    sendRequest();
  }, []);

  return (
    <div>
      <div className="moreCats " id="moreCats">
        <div className="categorys">
          <Link to="/bedroom" className="a">
            <div className="svgImg">
              <img src={bedroom} className="small" alt="Bedroom" />
              {/* style="width:50px" */}
            </div>
            <p className="ttl">Bedroom</p>
          </Link>
        </div>

        <div className="categorys">
          <Link to="/office" className="a">
            <div className="svgImg">
              <img src={office} className="small" alt="Office" />
            </div>
            <p className="ttl">Office</p>
          </Link>
        </div>

        <div className="categorys">
          <Link to="/kitchen" className="a">
            <div className="svgImg">
              <img src={kitchen} className="small" alt="Kitchen" />
            </div>
            <p className="ttl">Kitchen</p>
          </Link>
        </div>

        <div className="categorys">
          <Link to="/dining" className="a">
            <div className="svgImg">
              <img src={dining} className="small" alt="Dining" />
            </div>
            <p className="ttl">Dining</p>
          </Link>
        </div>

        <div className="categorys  active">
          <Link to="/livingroom" className="a">
            <div className="svgImg">
              <img src={livingroom} className="small" alt="Livingroom" />
              {/* style="width:50px" */}
            </div>
            <p className="ttl">Livingroom</p>
          </Link>
        </div>
      </div>

      <Fragment>
        <div className="wrapall">
          <div id="sorting">
            <form method="post">
              <select name="sort">
                <option value=" selected hidden">Sort By</option>
                <option value="maxprice">Maximum Price</option>
                <option value="minprice">Minimum Price</option>
              </select>

              <input type="submit" name="orderSearch" value="Sort" />
            </form>
          </div>

          <div id="titled">
            <h5> Livingroom Category </h5>
          </div>

          <div className="container" id="container">
            {loadedUser?.map((val, i) => {
              if (val.catagory == "Living") {
                return (
                  <div>
                    <Product data={val} />
                  </div>
                );
              }
            })}
          </div>
        </div>
      </Fragment>
      <Outlet />
    </div>
  );
};
export default Livingroom;
