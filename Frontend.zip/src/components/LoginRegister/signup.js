import React, { useState } from "react";

import "./login.css";

const Signup = () => {
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [lname, setLname] = useState("");
  const [fname, setFname] = useState("");
  const [phone, setPhone] = useState("");

  const SubmitData = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch("http://localhost:5000/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          password: password,
          phoneNumber: phone,
          role: "Normal",
          username: fname + " " + lname,
        }),
      });

      const responseData = await response.json();
      if (responseData.status == 200) {
        setEmail("");
        setPassword("");
        setFname("");
        setLname("");
        setPhone("");
        alert(responseData.message);
      } else {
        alert(responseData.message + ": " + responseData.error);
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div>
      <div className="wrapper">
        <form className="form-signup">
          <h2 className="form-signup-heading">Please Register</h2>
          <input
            type="text"
            className="form-control"
            id="firstname"
            name="firstname"
            value={fname}
            placeholder="Firstname"
            onChange={(e) => setFname(e.target.value)}
            required
          />
          <input
            type="text"
            className="form-control"
            id="lastname"
            value={lname}
            name="lastname"
            placeholder="Lastname"
            onChange={(e) => setLname(e.target.value)}
            required
          />
          <input
            type="text"
            className="form-control"
            id="Id"
            name="email"
            value={email}
            placeholder="Gmail ID"
            pattern=".+@gmail\.com"
            size="30"
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="number"
            className="form-control"
            id="number"
            value={phone}
            name="phone"
            placeholder="Contact Number"
            maxlength="10"
            onChange={(e) => setPhone(e.target.value)}
            required
          />

          <input
            type="password"
            className="form-control"
            id="password"
            value={password}
            name="password"
            placeholder="Set A Password"
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button
            className="btn btn-lg btn btn-dark btn-block"
            type="submit"
            onClick={SubmitData}
          >
            Register
          </button>
        </form>
      </div>
    </div>
  );
};

export default Signup;
