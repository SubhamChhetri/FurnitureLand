import React, { useState, useContext } from "react";

import { AuthContext } from "../../context/auth-context";
import "./login.css";

const Login = () => {
  const auth = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const SubmtData = async (event) => {
    event.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
        }),
      });

      const responseData = await response.json();

      auth.login(responseData.user, responseData.token, responseData.role);
      window.location.href = "/";
      if (responseData.status != 200) {
        alert(responseData.message + ": " + responseData.error);
      }
    } catch (err) {
      console.log(err);
    }
  };
  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  return (
    <div className="wrapper">
      <form className="form-signin">
        <h2 className="form-signin-heading">Please login</h2>
        <input
          type="text"
          className="form-control"
          name="email"
          placeholder="Email Address"
          required=""
          onChange={handleEmailChange}
        />
        <input
          type="password"
          className="form-control"
          name="password"
          placeholder="Password"
          required=""
          onChange={handlePasswordChange}
        />
        <label className="checkbox">
          <input
            type="checkbox"
            value="remember-me"
            className="ckbox"
            id="rememberMe"
            name="rememberMe"
          />{" "}
          Remember me
        </label>
        <button
          className="btn btn-lg btn btn-dark btn-block"
          type="submit"
          onClick={SubmtData}
        >
          Login
        </button>
        <p></p>
        <div className="register">
          <p>Don't have an account?</p>
          <a href="/signup">Signup</a>{" "}
        </div>
      </form>
    </div>
  );
};

export default Login;
