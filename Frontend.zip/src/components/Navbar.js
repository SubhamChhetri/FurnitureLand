import React, { useContext } from "react";

import { AuthContext } from "../context/auth-context";

import { Outlet } from "react-router-dom";

import Logo from "./image/furnitureland.png";
export default function Navbar() {
  const auth = useContext(AuthContext);
  const logout = () => {
    auth.logout();
    window.location.href = "/";
  };
  return (
    <div>
      <section id="nav">
        <nav className="navbar navbar-expand-lg navbar-light shadow-lg p-3 mb-5 bg-white rounded">
          <a className="navbar-brand" href="/">
            <img src={Logo} alt="furmitureland.logo" width="100%" />
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <form
              className="form-inline my-2 my-lg-0 bg-white"
              action="Customer/#"
              method="post"
            >
              <input
                className="form-control mr-sm-2"
                name="search"
                type="search"
                placeholder="Search by Name, Category or Shop..."
                aria-label="Search"
              />
            </form>
            {auth.isLoggedIn && auth.role == "Normal" && (
              <ul className="navbar-nav ml-auto">
                <li className="nav-item active user control">
                  <a className="nav-link" href="index.html">
                    <i className="fa fa-user"></i>{" "}
                    <i className="fas fa-caret-down"></i>{" "}
                  </a>
                  <a className="managedets" href="#">
                    My profile
                  </a>
                </li>

                <li
                  className="nav-item active logout control"
                  onClick={logout}
                  style={{ cursor: "pointer" }}
                >
                  <a className="nav-link">
                    <i className="fas fa-sign-out-alt"></i>Logout
                  </a>
                </li>
                <li className="nav-item active">
                  <a className="nav-link" href="/myCart">
                    <i className="fa fa-shopping-cart"></i> Items{" "}
                  </a>
                </li>
              </ul>
            )}
            {auth.isLoggedIn && auth.role != "Normal" && (
              <ul className="navbar-nav ml-auto">
                <li className="nav-item active user control">
                  <a className="nav-link" href="index.html">
                    <i className="fa fa-user"></i>{" "}
                    <i className="fas fa-caret-down"></i>{" "}
                  </a>
                  <a className="managedets" href="#">
                    My profile
                  </a>
                </li>

                <li
                  className="nav-item active logout control"
                  onClick={logout}
                  style={{ cursor: "pointer" }}
                >
                  <a className="nav-link">
                    <i className="fas fa-sign-out-alt"></i>Logout
                  </a>
                </li>
                <li className="nav-item active">
                  <a className="nav-link" href="myProduct">
                    <i className="fa fa-shopping-cart"></i>Add/Remove Products{" "}
                  </a>
                </li>
              </ul>
            )}
            {!auth.isLoggedIn && (
              <ul className="navbar-nav ml-auto">
                <li className="nav-item active control">
                  <a className="nav-link" id="signin" href="/login">
                    <i class="fa fa-sign-in" aria-hidden="true"></i> SignIn
                  </a>
                </li>
                <li className="nav-item active">
                  <a className="nav-link" id="signin" href="/signup">
                    <i class="fa fa-user-plus" aria-hidden="true"></i> Register
                  </a>
                </li>
              </ul>
            )}
          </div>
        </nav>
      </section>
      <Outlet />
    </div>
  );
}
