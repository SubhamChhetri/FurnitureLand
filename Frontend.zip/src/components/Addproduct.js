import React, { useState } from "react";
import "./css/addproduct.css";

const Addproduct = () => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [image, setImage] = useState("");
  const [price, setPrice] = useState("");
  const SubmtData = async (event) => {
    event.preventDefault();
    const storedData = JSON.parse(localStorage.getItem("userData"));
    try {
      const response = await fetch("http://localhost:5000/addFurniture", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer+" + storedData.token,
        },
        body: JSON.stringify({
          name: name,
          desc: description,
          catagory: category,
          location: location,
          img: image,
          price: price,
          creatorID: storedData.userId,
        }),
      });

      const responseData = await response.json();

      if (responseData.status == 200) {
        alert(responseData.message);
        window.location.href = "myProduct";
      } else {
        alert(responseData.message + ": " + responseData.error);
      }
      
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <div>
      <div class="containerAdd">
        <div class="add-product">
          <form>
            <div>
              <label>Product name:</label>
              <input
                type="text"
                placeholder=""
                onChange={(e) => setName(e.target.value)}
              />
            </div>

            <div>
              <label>Product description:</label>
              <textarea
                placeholder="Sample description..."
                rows="7"
                cols="50"
                onChange={(e) => setDescription(e.target.value)}
              ></textarea>
            </div>

            <div>
              <lable>Category:</lable>
              <br></br>
              <select
                id="categoris"
                className="categories"
                name="category"
                onChange={(e) => setCategory(e.target.value)}
                default
              >
                <option value="0">Select Category:</option>
                <option value="Bedroom">Bedroom</option>
                <option value="Living">Livingroom</option>
                <option value="Kitchen">Kitchen</option>
                <option value="Dining">Dining</option>
                <option value="Office">Office</option>
              </select>
            </div>

            <div>
              <label>Location:</label>
              <input
                type="text"
                placeholder="location"
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
            <div>
              <label>Product image:</label>
              <input
                type="text"
                placeholder=""
                onChange={(e) => setImage(e.target.value)}
              />
            </div>

            <div>
              <label>Price:</label>
              <input
                type="number"
                id="quantity"
                name="quantity"
                min="1"
                max="5"
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>

            <button onClick={SubmtData}>Add</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Addproduct;
