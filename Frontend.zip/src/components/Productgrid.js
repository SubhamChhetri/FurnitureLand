import React from "react";

import "./css/shopbycategory.css";

import Bedroom from "./image/bedroom.jpg";
import Livingoom from "./image/livingroom.jpg";
import Dining from "./image/dining.jpg";
import Kitchen from "./image/kitchen.jpg";
import Office from "./image/office.jpg";

import { Outlet, Link } from "react-router-dom";

export default function Productgrid() {
  return (
    <div>
      <section id="sortbyCats">
        <div id="sortbyCats">
          <h2
            className="title negative"
            style={{ marginTop: 20, marginBottom: 20 }}
          >
            {" "}
            Shop by Category{" "}
          </h2>
        </div>

        <div className="images">
          <div className="category">
            <Link to="/bedroom" className="a">
              <img src={Bedroom} alt="Bedroom" />
              <p>Bedroom</p>
            </Link>
          </div>

          <div className="category">
            <Link to="/livingroom" className="a">
              <img src={Livingoom} alt="Livingroom" />
              <p>Livingoom</p>
            </Link>
          </div>

          <div className="category">
            <Link to="/dining" className="a">
              <img src={Dining} alt="Dining" />
              <p>Dining</p>
            </Link>
          </div>

          <div className="category">
            <Link to="/kitchen" className="a">
              <img src={Kitchen} alt="Kitchen" />
              <p>Kitchen</p>
            </Link>
          </div>

          <div className="category">
            <Link to="/office" className="a">
              <img src={Office} alt="Office" />
              <p>Office</p>
            </Link>
          </div>
        </div>
      </section>
      <Outlet />
    </div>
  );
}
