import React from "react";
import Carsole from "react-material-ui-carousel";

import "../css/productView.css";
import "./ProductDetails.css";
import { useSelector } from "react-redux";

const ProductDetails = ({ match }) => {

  const { product} = useSelector(
    (state) => state.productDetails
  );

  return (
    <div className="ProductDetails">
      <div>
        <Carsole>
          {product.images &&
            product.images.map((item, i) => (
              <img
                className="CarouselImage"
                key={item.url}
                src={item.url}
                alt={`${i} Slide`}
              />
            ))}
        </Carsole>
      </div>
    </div>
  );
};

export default ProductDetails;
