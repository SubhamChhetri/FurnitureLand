import React from "react";
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";

import "./css/productView.css";

const Productview = () => {
  const productID = useParams().id;
  const [loadedData, setLoadedData] = useState();

  useEffect(() => {
    const sendRequest = async () => {
      try {
        const response = await fetch(
          `http://localhost:5000/furniture/${productID}`
        );
        const responseData = await response.json();
        setLoadedData(responseData.furnitures);
      } catch (err) {
        console.log(err);
      }
    };
    sendRequest();
  }, []);

  const addToCart = async () => {
    try {
      const storedData = JSON.parse(localStorage.getItem("userData"));

      const response = await fetch(
        `http://localhost:5000/cart/${productID}/add`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer+" + storedData.token,
          },
        }
      );
      const responseData = await response.json();

      if (responseData.status == 200) {
        alert(responseData.message);
      } else {
        alert(responseData.message + ": " + responseData.error);
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div>
      <div id="content-wrapper" style={{ marginTop: 60 }}>
        <div className="column">
          <img id="featured" src={loadedData?.img} width="500px" />

          <div id="slide-wrapper">
            <img id="slideLeft" className="arrow" src="images/arrow-left.png" />

            <div id="slider">
              <img className="thumbnail active" src={loadedData?.img} />
              <img className="thumbnail" src="images/shoe2.jpg" />
              <img className="thumbnail" src="images/shoe3.jpg" />

              <img className="thumbnail" src="images/preset1.png" />
              <img className="thumbnail" src="images/preset2.jpg" />
              <img className="thumbnail" src="images/preset3.jpg" />
              <img className="thumbnail" src="images/preset4.jpg" />
            </div>

            <img
              id="slideRight"
              className="arrow"
              src="images/arrow-right.png"
            />
          </div>
        </div>

        <div className="column">
          <h1>{loadedData?.name}</h1>
          <h6>
            <b>ID: </b>
            {loadedData?._id}
          </h6>
          <h5>#{loadedData?.catagory}</h5>
          <hr></hr>
          <h5>${loadedData?.price}</h5>

          <p>{loadedData?.desc}</p>
          <a className="btn btn-dark" onClick={addToCart}>
            Add to Cart
          </a>
        </div>
      </div>
    </div>
  );
};

export default Productview;
