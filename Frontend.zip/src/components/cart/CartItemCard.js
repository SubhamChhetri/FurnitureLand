import React from "react";

import "./CartItemCard.css";
import { Link } from "react-router-dom";

const CartItemCard = ({ item, deleteCartItems }) => {
  return (
    <div className="CartItemCard">
      <img src={item.img} alt="gafa" />
      <div className="textspace">
        <Link to={`/${item.furnitureID}/product`}>{item.name}</Link>
        <span>{`Price: ₹${item.price}`}</span>

        <p onClick={() => deleteCartItems(item._id)}>Remove</p>
      </div>

      <div className="total">
        <p className="cartSubtotal">{`₹${item.price}`} </p>
      </div>
    </div>
  );
};

export default CartItemCard;
