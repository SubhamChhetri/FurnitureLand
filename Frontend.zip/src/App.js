import "./App.css";
import "./components/css/nav.css";
import "./components/css/banner.css";
import "./components/css/body.css";
import "./components/css/Carsole.css";

import "./components/css/space.css";
import "./components/css/review.css";
import "./components/css/footer.css";

import MetaData from "./components/layout/MetaData";

import Navbar from "./components/Navbar";

import Error from "./components/Error";
import Login from "./components/LoginRegister/login";
import Signup from "./components/LoginRegister/signup";
import Productview from "./components/Productview";
import Shop from "./components/Shops/Shop";
import Addproduct from "./components/Addproduct";
import MyProduct from "./components/myProduct";
import Office from "./components/Category/Office";
import Kitchen from "./components/Category/Kitchen";
import Livingroom from "./components/Category/Livingroom";
import Dining from "./components/Category/Dining";
import Bedroom from "./components/Category/Bedroom";
import Cart from "./components/cart/Cart";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./home/home";
import { useCallback, useEffect, useState } from "react";
import { AuthContext } from "./context/auth-context";

let logoutTimer;

const App = () => {
  const [isToken, setToken] = useState(false);
  const [tokenExpiration, setTokenExpiration] = useState();
  const [userId, setUserId] = useState(false);
  const [role, setRole] = useState(false);

  const login = useCallback((uid, token, role, expirationDate) => {
    setToken(token);
    setUserId(uid);
    setRole(role);
    const tokenExpiration =
      expirationDate || new Date(new Date().getTime() + 1000 * 60 * 60 * 3);
    setTokenExpiration(tokenExpiration);
    localStorage.setItem(
      "userData",
      JSON.stringify({
        userId: uid,
        token: token,
        role: role,
        expiration: tokenExpiration.toISOString(),
      })
    );
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setTokenExpiration(null);
    setUserId(null);
    setRole(null);
    localStorage.removeItem("userData");
  }, []);

  useEffect(() => {
    if (isToken && tokenExpiration) {
      const remainingTime = tokenExpiration.getTime() - new Date().getTime();
      logoutTimer = setTimeout(logout, remainingTime);
    } else {
      clearTimeout(logoutTimer);
    }
  }, [isToken, logout]);

  useEffect(() => {
    const storedData = JSON.parse(localStorage.getItem("userData"));
    if (
      storedData &&
      storedData.token &&
      new Date(storedData.expiration) > new Date()
    ) {
      login(
        storedData.userId,
        storedData.token,
        storedData.role,
        new Date(storedData.expiration)
      );
    }
  }, [login]);

  return (
    <AuthContext.Provider
      value={{
        isLoggedIn: !!isToken,
        token: isToken,
        userId: userId,
        role: role,
        login: login,
        logout: logout,
      }}
    >
      <div>
        <MetaData title="Furniture Land" />
        <div className="About head">
          <Navbar />
        </div>
        <Router>
          <Routes>
            <Route path="/" exact element={<Home />} />
            <Route path="*" element={<Error />} />
            <Route path="/bedroom" element={<Bedroom />} />
            <Route path="/Livingroom" element={<Livingroom />} />
            <Route path="/office" element={<Office />} />
            <Route path="/dining" element={<Dining />} />
            <Route path="/kitchen" element={<Kitchen />} />
            <Route path="/myProduct" element={<MyProduct />} />
            <Route path="/addproduct" element={<Addproduct />} />
            <Route path="/kitchen" element={<Kitchen />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/MyCart" element={<Cart />}/>
            <Route path="/:id/product" element={<Productview />} exact />
          </Routes>
        </Router>

        <div className="About">
          <Router>
           
          </Router>
        </div>

        <div className="About space"></div>
      </div>
    </AuthContext.Provider>
  );
};

export default App;
