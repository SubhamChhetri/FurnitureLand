import Sidebar from "./sidebar";

export default function Shop() {
   
  return (
      <div>
          <Sidebar />
      </div>
  );
}
